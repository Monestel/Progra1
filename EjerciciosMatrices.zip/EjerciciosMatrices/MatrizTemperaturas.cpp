//
// Created by david on 1/18/2026.
//

#include "MatrizTemperaturas.h"